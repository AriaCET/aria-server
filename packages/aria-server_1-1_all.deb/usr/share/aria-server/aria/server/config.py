from os.path import join 
asteriskconf='/etc/asterisk'
DB_path = "/etc/aria-server/ariaDB"
clientConf = join(asteriskconf,'sip.conf')
channelConf = join(asteriskconf,'extensions.conf')
